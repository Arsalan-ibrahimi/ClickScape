chrome.action.onClicked.addListener(function (tab) {
    console.log('hello');
});